# Manuscript preparation record

Prepared on 2026-10-13 with the scientific-writing and pdf skills.

## Evidence and editorial decisions

The reference paper was read from the supplied PDF. The experiment workbook, 25-slide PowerPoint, Demo documentation, detector source, split manifests, 21 archived runs and 41 saved evaluations were examined. A separate trained Final3D run and its existing CPU diagnostics were incorporated after their identities and protocols were established.

Raw evaluation JSON takes precedence over spreadsheet formatting. Hist14, independent BEV heads, and the shared Final3D head are described from code and checkpoint/configuration evidence. One post-run head field was removed from copies of all 21 BEV configs to reproduce their recorded training SHA-256 values exactly. Both supplied and recovered copies remain in the package. The source experiment directories were not edited.

The main text separates local BEV, full-frame reference BEV/3D, and conditional CPU diagnostics. Claims of SOTA, repeated-seed significance, test-set accuracy, equal-recall false-positive improvements, and embedded-device performance are absent because the supplied evidence does not establish them. Demo cuboids with LiDAR-derived vertical extent are captioned accordingly.

The existing vector architecture counterpart is used for the main diagram. The original editable PowerPoint is preserved byte-for-byte, and its raster images and recursive text inventory are extracted. Early diagram labels are not used to override saved model specifications. Three new scientific plots are generated from saved numeric values and provided as PDF, SVG and 300-dpi PNG.

## Render and reference checks

Both documents were compiled with Tectonic 0.17.0 using IEEEtran/BibTeX for the main manuscript. Main: 8 pages; supplementary: 11 pages. All 23 BibTeX entries are cited across the two documents, with no missing or unused keys. No unresolved cross-reference, missing figure, source citation placeholder or overfull box remains. PDF font listings confirm all fonts are embedded. The main document retains minor underfull spacing warnings, mostly in long reference URLs; they do not represent cropped or overflowing content.

Page contact sheets and detailed pages covering the equations, provenance and tables were inspected visually. `document_checks.json` stores the final PDF digests and exact counts. `build_logs/` records compiler output. The 29-file source ZIP contains sources, bibliography, generated bibliography files, tables and figures used by the documents; it does not require the original training archives to compile.

## Next author revision

Replace the anonymous author line and add venue-specific author/funding information. The English manuscript is complete as a draft grounded in the available experiments. Baselines, repeated seeds and matched 3D head experiments recommended in `venue_strategy_vi.md` remain future work. No new detector training, inference or detector test was performed during manuscript preparation.
